package com.br.ruy.padrao.composite;


public class ArquivoVideoTransparente extends ArquivoComponenteTransparente{
    
    public ArquivoVideoTransparente(String nomedoarquivo){
        this.setNomearquivo(nomedoarquivo);
    }
    
}
