package com.br.ruy.padrao.template.enumerador;


public enum ModoDeReproducao {
    porNome,
    porAutor,
    porAno,
    porEstrela
}
