
package com.br.ruy.padrao.adapter;


public interface IImagemTarget {
    
    void setCarregarImagem(String nomedoarquivo);
    
    void getDesenharImagem(int posx, int posy, int largura, int altura);
    
}
