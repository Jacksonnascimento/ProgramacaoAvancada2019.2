
package aula4;

import com.br.ruy.padrao.adapter.ImagemAdapter;
import com.br.ruy.padrao.adapter.ImagemTarget;
import com.br.ruy.padrao.adapter.OpenGlImagemAdapter;
import com.br.ruy.padrao.singletom.Pessoa;


public class Aula4 {

   
    public static void main(String[] args) {
        ImagemTarget imagem = new ImagemAdapter();
        imagem.setCarregarImagem("FiguraCasa.png");
        imagem.getDesenharImagem(0, 1, 10, 20);
        
        imagem = new OpenGlImagemAdapter();
        imagem.setCarregarImagem("FiguraPlanoDeFundo.jpeg");
        imagem.getDesenharImagem(1, 4, 50, 60);
        
        System.out.println("\n\n");
        
        Pessoa p1 = Pessoa.getInstancia();
        Pessoa p2 = Pessoa.getInstancia();
       
        p1.setNome("Maria");
        p1.setCpf("064552151");
        p1.setAltura((float) 1.8);
        
        p2.setNome("Fernando");
        p2.setCpf("0634343");
        p2.setAltura((float) 1.60);
        
        System.out.println(p1);
        System.out.println(p2);
        System.out.println("Nome: " + p1.getNome() + "\nCPF: " + p1.getCpf() + "\nAltura: " + p1.getAltura());
        System.out.println("Nome: " + p2.getNome() + "\nCPF: " + p2.getCpf() + "\nAltura: " + p2.getAltura());
    }
    
}
