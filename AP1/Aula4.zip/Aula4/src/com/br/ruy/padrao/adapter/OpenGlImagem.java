
package com.br.ruy.padrao.adapter;


public class OpenGlImagem {
  
    public void setGlCarregarImagem(String arquivo){
        //implementação de carregamento de uma imagem openGl
        
        System.out.println("Imagem carregada: " + arquivo);
    }
    
    public void setDesenhaImagem(int posicaox, int posicaoy){
        //implementação de imagem openGl
    
            System.out.println("Open Gl imagem desenhada: " +  " X:" + posicaox + " Y: " + posicaoy);
    
    }
}
