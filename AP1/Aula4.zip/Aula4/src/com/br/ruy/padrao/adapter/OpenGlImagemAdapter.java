//
package com.br.ruy.padrao.adapter;


public class OpenGlImagemAdapter extends OpenGlImagem implements ImagemTarget{

    @Override
    public void setCarregarImagem(String nomedoarquivo) {
        setGlCarregarImagem(nomedoarquivo);
       
    }

    @Override
    public void getDesenharImagem(int posx, int posy, int largura, int altura) {
        setDesenhaImagem(posx - largura, posy + altura);
    }
    
}
