/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.ruy.padrao.observer;

/**
 *
 * @author 161051914
 */
public class Dados {
    private int valora;
    private int valorb;
    private int valorc;
    private int valord;

    public Dados(int valora, int valorb, int valorc, int valord) {
        this.valora = valora;
        this.valorb = valorb;
        this.valorc = valorc;
        this.valord = valord;
    }

    public int getValora() {
        return valora;
    }

    public void setValora(int valora) {
        this.valora = valora;
    }

    public int getValorb() {
        return valorb;
    }

    public void setValorb(int valorb) {
        this.valorb = valorb;
    }

    public int getValorc() {
        return valorc;
    }

    public void setValorc(int valorc) {
        this.valorc = valorc;
    }

    public int getValord() {
        return valord;
    }

    public void setValord(int valord) {
        this.valord = valord;
    }
    
}
