/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.ruy.padrao.observer;

/**
 *
 * @author 161051914
 */
public class TabelaObserver extends DadosObserver{

    public TabelaObserver(DadosSubject dados) {
        super(dados);
    }

    @Override
    public void update() {
        System.out.println("Tabela dos Valores");
        System.out.println("Valor A:" + dados.getState().getValora());
        System.out.println("Valor B:" + dados.getState().getValorb());
        System.out.println("Valor C:" + dados.getState().getValorc());
        System.out.println("Valor D:" + dados.getState().getValord());
    }
    
}
