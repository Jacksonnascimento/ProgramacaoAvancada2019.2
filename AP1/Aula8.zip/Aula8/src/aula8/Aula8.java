
package aula8;

import frb.edu.br.padrao.strategy.Funcionario;


public class Aula8 {

    
    public static void main(String[] args) {
        Funcionario funcionario1 = new Funcionario(2100, Funcionario.DESENVOLVEDOR, "Zé Ramalho");
        
        Funcionario funcionario2 = new Funcionario(1700, Funcionario.ANALISTA, "João Estágio");
        
        Funcionario funcionario3 = new Funcionario(4000, Funcionario.GERENTE, "Chefe legal");
        
        System.out.println("Funcionário: " + funcionario1.getNome());
        System.out.println("Cargo: " + funcionario1.getDescricaocargo());
        System.out.println("Salário base: " + funcionario1.getSalariobruto());
        System.out.println("Salário liquido: " + funcionario1.getCalculaSalarioLiquido());
        System.out.println("------------------------------------------------------------");
        
        System.out.println("Funcionário: " + funcionario2.getNome());
        System.out.println("Cargo: " + funcionario2.getDescricaocargo());
        System.out.println("Salário base: " + funcionario2.getSalariobruto());
        System.out.println("Salário liquido: " + funcionario2.getCalculaSalarioLiquido());
        System.out.println("------------------------------------------------------------");
        
        System.out.println("Funcionário: " + funcionario3.getNome());
        System.out.println("Cargo: " + funcionario3.getDescricaocargo());
        System.out.println("Salário base: " + funcionario3.getSalariobruto());
        System.out.println("Salário liquido: " + funcionario3.getCalculaSalarioLiquido());
        System.out.println("------------------------------------------------------------");
    }
    
}
