
package frb.edu.br.padrao.strategy;


public interface CalculaImposto {
    double calculaSalarioComImposto(Funcionario umfuncionario);
}
