
package com.br.ruy.padrao.composite;


public class ArquivoVideoTransparente extends ArquivoComponenteTransparente{
    
    public  ArquivoVideoTransparente (String nomearquivo){
       this.setNomearquivo(nomearquivo);
    }
    
}
