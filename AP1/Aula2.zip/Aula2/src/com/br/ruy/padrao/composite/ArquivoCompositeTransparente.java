
package com.br.ruy.padrao.composite;

import java.util.ArrayList;


public class ArquivoCompositeTransparente extends ArquivoComponenteTransparente{
    ArrayList<ArquivoComponenteTransparente> arquivos = new ArrayList<ArquivoComponenteTransparente>();

    public ArquivoCompositeTransparente(String nomearquivo) {
        this.setNomearquivo(nomearquivo);
    }
    
    
    @Override
   public void adicionar(ArquivoComponenteTransparente novoarquivo){
       this.arquivos.add(novoarquivo);
   }
   
    @Override
   public void remover(String nomearquivo) throws Exception{
        for (ArquivoComponenteTransparente arquivo : arquivos) {
            if(arquivo.getNomearquivo().equals(nomearquivo)){
                this.arquivos.remove(arquivo);
                return;
            }
        }
        throw  new Exception("Não encontrei o arquivo");
   }
   
    @Override
   public ArquivoComponenteTransparente getArquivo(String nomearquivo) throws Exception{
       for (ArquivoComponenteTransparente arquivo : arquivos) {
            if(arquivo.getNomearquivo().equals(nomearquivo)){
                this.arquivos.remove(arquivo);
                return arquivo;
            }
        }
        throw  new Exception("Não encontrei o arquivo");
   }
}
