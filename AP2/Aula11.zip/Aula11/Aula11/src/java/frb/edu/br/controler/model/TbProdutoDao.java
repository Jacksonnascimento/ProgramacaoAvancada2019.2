/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package frb.edu.br.controler.model;

import frb.edu.br.entity.TbPodutoDto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author 161051914
 */
public class TbProdutoDao extends DaoUtil {

    public TbProdutoDao() {
        super();
    }

    public boolean setAdicionar(TbPodutoDto prod) throws ClassNotFoundException, SQLException {
        String sql = "INSERT INTO tbProduto "
                + "(nome, preco, validade, descricao) "
                + "VALUES (?, ?, ?, ?)";

        PreparedStatement ps = super.getPreparedStatement(sql);
        ps.setString(1, prod.getNome());
        ps.setFloat(2, prod.getPreco());
        ps.setDate(3, new java.sql.Date(prod.getValidade().getTime()));
        ps.setString(4, prod.getDescricao());
        int ret = ps.executeUpdate();
        ps.close();
        super.getFechaConnection();
        return ret > 0;
    }
    
    public boolean setAlterar(TbPodutoDto prod) throws ClassNotFoundException, SQLException {
        String sql = "UPDATE tbProduto SET "
                + "(nome =?, preco = ?, validade = ?, descricao + ?) "
                + "WHERE idProduto = 2";

        PreparedStatement ps = super.getPreparedStatement(sql);
        ps.setString(1, prod.getNome());
        ps.setFloat(2, prod.getPreco());
        ps.setDate(3, new java.sql.Date(prod.getValidade().getTime()));
        ps.setString(4, prod.getDescricao());
        ps.setInt(5, prod.getIdproduto());
        int ret = ps.executeUpdate();
        ps.close();
        super.getFechaConnection();
        return ret > 0;
    }
    
    public boolean setDeletar(TbPodutoDto prod) throws ClassNotFoundException, SQLException {
        String sql = "DELETE FROM tbProduto SET "
                + "WHERE idProduto = 2";

        PreparedStatement ps = super.getPreparedStatement(sql);
        int ret = ps.executeUpdate();
        ps.close();
        super.getFechaConnection();
        return ret > 0;
    }
    
    public LinkedList<TbPodutoDto> getTodos() throws ClassNotFoundException, SQLException{
        String sql = "SELECT idPoduto, nome, preco, " +
                "validade, descricao From tbPoduto";
        LinkedList<TbPodutoDto> lstret = new LinkedList<TbPodutoDto>();
        
        PreparedStatement ps = super.getPreparedStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while ( rs.next()){
            TbPodutoDto aux = new TbPodutoDto();
            
            lstret.add(
                    
                    new TbPodutoDto(rs.getInt("idProduto"), rs.getString("nome"), rs.getFloat("preco"), 
                            rs.getDate("validade"), rs.getString("descricao")));
        }
        
        rs.close();
        ps.close();
        super.getFechaConnection();
        
        
        return lstret;
    }
    
      public TbPodutoDto getPorId(TbPodutoDto prod) throws ClassNotFoundException, SQLException{
        String sql = "SELECT idPoduto, nome, preco, " +
                "validade, descricao From tbPoduto " + 
                "WHERE idProduto = ?";
        
        
        TbPodutoDto dtoret = new TbPodutoDto();
        
        while ( rs.next()){
            TbPodutoDto aux = new TbPodutoDto();
            
            lstret.add(
                    
                    new TbPodutoDto(rs.getInt("idProduto"), rs.getString("nome"), rs.getFloat("preco"), 
                            rs.getDate("validade"), rs.getString("descricao")));
        }
        
        rs.close();
        ps.close();
        super.getFechaConnection();
        
        
        return lstret;
    }
}

}
