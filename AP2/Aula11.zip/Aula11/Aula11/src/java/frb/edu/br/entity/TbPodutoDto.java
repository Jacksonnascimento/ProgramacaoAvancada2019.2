
package frb.edu.br.entity;

import java.util.Date;


public class TbPodutoDto {
    private int Idproduto;
    private String nome;
    private float preco;
    private Date validade;
    private String descricao;

    public TbPodutoDto() {
    }

    public TbPodutoDto(int Idproduto, String nome, float preco, Date validade, String descricao) {
        this.Idproduto = Idproduto;
        this.nome = nome;
        this.preco = preco;
        this.validade = validade;
        this.descricao = descricao;
    }

    public int getIdproduto() {
        return Idproduto;
    }

    public void setIdproduto(int Idproduto) {
        this.Idproduto = Idproduto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public Date getValidade() {
        return validade;
    }

    public void setValidade(Date validade) {
        this.validade = validade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
}
